package com.project

/** Displays the question state text based on whether the user is looking at answer or not */
fun displayQuestionStateTest(state: QuestionBankState, questions: List<Question>): String {
    if (state.lookingAtAnswer) {
        return "A: ${questions[state.currentQuestion].answer}. Were you correct? (y/n)"
    }
    return "Q: ${questions[state.currentQuestion].question}. Press Enter to see the answer."
}

/** Retrieves the next question state based on the user input */
fun nextQuestionState(state: QuestionBankState, inp: String): QuestionBankState {

    // user has pressed enter, show the answer
    if (inp.isNullOrEmpty()) {
        return QuestionBankState(state.currentQuestion, true, state.correctAnswers)
    }
    // user has entered some input, check if it is correct
    val isAnswerCorrect = isCorrect(inp)
    val newCorrectAnswers = if (isAnswerCorrect) state.correctAnswers + 1 else state.correctAnswers
    val newLookingAtAnswer = false
    val newCurrentQuestion = state.currentQuestion + 1
    val newState = QuestionBankState(newCurrentQuestion, newLookingAtAnswer, newCorrectAnswers)

    return newState
}

/** Function to loop over a questions list in the question bank */
fun studyQuestionBank(
        questions: List<Question>,
        initialState: QuestionBankState
): QuestionBankState {
    return khoury.reactConsole(
            initialState,
            { state -> displayQuestionStateTest(state, questions) },
            { state, inp -> nextQuestionState(state, inp) },
            { state -> state.currentQuestion >= questions.size },
            { state -> "You got ${state.correctAnswers} correct!" }
    )
}

fun chooseBank(questionBanks: List<QuestionBank>): List<Question> {
    while (true) {
        println(
                "Welcome to Question Time! You can choose from ${questionBanks.size} question banks:"
        )
        questionBanks.mapIndexed { index, questionBank ->
            println("${index + 1}. ${questionBank.name}")
        }

        println("Enter your choice:")

        val choice: String = khoury.input()

        if (khoury.isAnInteger(choice)) {
            val choiceInt = choice.toInt()
            if (choiceInt in 1..questionBanks.size) {
                return questionBanks[choiceInt - 1].questions
            }
        }
        println("Invalid choice, please enter a number between 1 and ${questionBanks.size}")
    }
}

package com.project

class Question(val question: String, val answer: String) {
    override fun toString(): String {
        return "Question(question=$question, answer=$answer)"
    }
}

// fun main() {
//     val question1 = Question("What is 4 + 4 ?", "8")
//     val question2 = Question("What is 2 cubed ?", "8")
//     val question3 = Question(question = "What is the boiling point of water ?", answer = "100°C")
//     println(question1)
//     println(question2)
//     println(question3)
// }

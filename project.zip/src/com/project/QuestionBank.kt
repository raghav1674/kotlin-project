package com.project

class QuestionBank(val name: String, val questions: List<Question>) {

    /** Custom toString method to print the question bank in a readable format. */
    override fun toString(): String {
        val questionsString = questions.joinToString(separator = "\n") { it.toString() }
        return "Question Bank: $name\nQuestions:\n$questionsString"
    }
}

// fun main() {
//     // Example questions
//     val question1 = Question("What is 1 cubed ?", "1")
//     val question2 = Question("What is the boiling point of water?", "100°C")

//     // Create example question banks
//     val generalKnowledgeBank = QuestionBank(name = "Maths Quiz", questions = listOf(question1))
//     val scienceQuizBank = QuestionBank(name = "Science Quiz", questions = listOf(question2))

//     // Print the question banks
//     println(generalKnowledgeBank)
//     println()
//     println(scienceQuizBank)

//     // Generate a question bank with 5 questions
//     val cubesQuiz = cubes(5)
//     println()
//     println(cubesQuiz)
// }

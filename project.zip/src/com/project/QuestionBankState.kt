package com.project

class QuestionBankState(
        val currentQuestion: Int,
        val lookingAtAnswer: Boolean,
        val correctAnswers: Int
) {
    override fun toString(): String {
        return "QuestionBankState(currentQuestion=$currentQuestion, lookingAtAnswer=$lookingAtAnswer, correctAnswers=$correctAnswers"
    }
}

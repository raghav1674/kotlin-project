package com.project

import java.io.File

/** Function to generate a question bank with questions about perfect cubes. */
fun cubes(count: Int): QuestionBank {
    val questions =
            List(count) { i ->
                val n = i + 1 // The number being cubed, starting from 1
                Question("What is $n cubed?", "${n * n * n}")
            }
    // Return the QuestionBank with the generated questions
    return QuestionBank(name = "Perfect Cubes Quiz", questions = questions)
}

/** Converts a Question object to a string format suitable for storage, ie, "question|answer" */
fun questionToString(question: Question): String {
    return "${question.question}|${question.answer}"
}

/** Converts a string in the format "question|answer" to a Question object. */
fun stringToQuestion(str: String): Question {
    // Split the input string by the pipe character
    val parts = str.split("|")

    // Check if we have exactly two parts
    if (parts.size != 2) {
        throw IllegalArgumentException("Input string must be in the format 'question|answer'")
    }

    // Create and return a new Question object
    return Question(parts[0], parts[1])
}

/** Reads questions from a file and returns a sequence of Question objects. */
fun readQuestionBank(path: String): List<Question> {
    val file = File(path)

    // Check if the file exists
    if (!file.exists()) {
        return emptyList() // Return an empty list if the file does not exist
    }

    // Read lines from the file and convert them to Question objects
    return file.readLines().map { stringToQuestion(it) }
}

/** Checks if the supplied string starts with 'y' or 'Y'. */
fun isCorrect(input: String): Boolean {
    return input.lowercase().startsWith('y')
}
